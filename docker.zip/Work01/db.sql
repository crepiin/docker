CREATE TABLE books (
title VARCHAR(255),
author VARCHAR(255), 
qty int(30) 
)